#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Estrutura

// Nó da árvore binária representando uma sala
typedef struct Sala {
    char nome[50];      // Nome da sala
    char pista[100];    // Pista encontrada na sala (se existir)
    struct Sala* esquerda; // Sala à esquerda
    struct Sala* direita;  // Sala à direita
} Sala;

// Nó da BST que armazena pistas coletadas
typedef struct PistaNode {
    char pista[100];            // Conteúdo da pista
    struct PistaNode* esquerda;
    struct PistaNode* direita;
} PistaNode;

// Estrutura simples de tabela hash para associar pistas a suspeitos
typedef struct HashEntry {
    char pista[100];    // Chave: pista
    char suspeito[50];  // Valor: suspeito
} HashEntry;

//Hash Table

#define HASH_SIZE 100

HashEntry hashTable[HASH_SIZE];

// Função hash simples baseada na soma dos caracteres
int hash(char* key) {
    int sum = 0;
    for (int i = 0; key[i] != '\0'; i++)
        sum += key[i];
    return sum % HASH_SIZE;
}

// Inserir pista na hash
void inserirNaHash(char* pista, char* suspeito) {
    int idx = hash(pista);
    // Colisão simples: encontrar próximo espaço vazio
    while (hashTable[idx].pista[0] != '\0') {
        idx = (idx + 1) % HASH_SIZE;
    }
    strcpy(hashTable[idx].pista, pista);
    strcpy(hashTable[idx].suspeito, suspeito);
}

// Buscar suspeito associado à pista
char* encontrarSuspeito(char* pista) {
    int idx = hash(pista);
    int start = idx;
    while (hashTable[idx].pista[0] != '\0') {
        if (strcmp(hashTable[idx].pista, pista) == 0)
            return hashTable[idx].suspeito;
        idx = (idx + 1) % HASH_SIZE;
        if (idx == start) break; // toda a tabela já foi percorrida
    }
    return "Desconhecido";
}

//BST de Pistas

// Criar nó de pista
PistaNode* criarPistaNode(char* pista) {
    PistaNode* node = (PistaNode*)malloc(sizeof(PistaNode));
    strcpy(node->pista, pista);
    node->esquerda = node->direita = NULL;
    return node;
}

// Inserir pista na BST (ordem alfabética)
PistaNode* inserirPista(PistaNode* raiz, char* pista) {
    if (raiz == NULL) return criarPistaNode(pista);
    if (strcmp(pista, raiz->pista) < 0)
        raiz->esquerda = inserirPista(raiz->esquerda, pista);
    else if (strcmp(pista, raiz->pista) > 0)
        raiz->direita = inserirPista(raiz->direita, pista);
    return raiz;
}

// Exibir BST in-order (alfabético)
void exibirPistas(PistaNode* raiz) {
    if (raiz == NULL) return;
    exibirPistas(raiz->esquerda);
    printf("Pista: %s -> Suspeito: %s\n", raiz->pista, encontrarSuspeito(raiz->pista));
    exibirPistas(raiz->direita);
}

//Árvore da Mansão

// Criar sala
Sala* criarSala(char* nome, char* pista) {
    Sala* sala = (Sala*)malloc(sizeof(Sala));
    strcpy(sala->nome, nome);
    if (pista != NULL)
        strcpy(sala->pista, pista);
    else
        sala->pista[0] = '\0';
    sala->esquerda = sala->direita = NULL;
    return sala;
}

// Exploração da mansão com coleta de pistas
void explorarSalasComPistas(Sala* sala, PistaNode** arvorePistas) {
    if (sala == NULL) return;
    printf("\nVocê está na sala: %s\n", sala->nome);
    if (sala->pista[0] != '\0') {
        printf("Você encontrou uma pista: %s\n", sala->pista);
        *arvorePistas = inserirPista(*arvorePistas, sala->pista);
    }

    char opcao;
    do {
        printf("Escolha o próximo caminho: esquerda (e), direita (d), sair (s): ");
        scanf(" %c", &opcao);
        if (opcao == 'e') {
            explorarSalasComPistas(sala->esquerda, arvorePistas);
            break;
        } else if (opcao == 'd') {
            explorarSalasComPistas(sala->direita, arvorePistas);
            break;
        } else if (opcao == 's') {
            printf("Você decidiu sair da exploração.\n");
            break;
        } else {
            printf("Opção inválida.\n");
        }
    } while (1);
}

//Main

int main() {
    // Inicializar tabela hash
    for (int i = 0; i < HASH_SIZE; i++)
        hashTable[i].pista[0] = '\0';

    // Criar suspeitos
    char* suspeitos[] = {"Sr. Black", "Sra. White", "Detetive Azul", "Prof. Green"};

    // Criar mapa da mansão
    Sala* hall = criarSala("Hall de Entrada", "Pegadas de botas sujas");
    Sala* cozinha = criarSala("Cozinha", "Manchas de farinha");
    Sala* biblioteca = criarSala("Biblioteca", "Livro fora do lugar");
    Sala* jardim = criarSala("Jardim", "Pegadas no gramado");
    Sala* salaEstar = criarSala("Sala de Estar", "Vidro quebrado na janela");
    Sala* escritorio = criarSala("Escritório", "Carta suspeita sobre a mesa");
    Sala* quarto = criarSala("Quarto Principal", "Frasco de veneno");
    Sala* banheiro = criarSala("Banheiro", "Rastros de maquiagem");

    // Montagem da árvore da mansão
    hall->esquerda = cozinha;
    hall->direita = biblioteca;
    cozinha->esquerda = salaEstar;
    cozinha->direita = jardim;
    biblioteca->esquerda = escritorio;
    biblioteca->direita = quarto;
    quarto->direita = banheiro;

    // Associar pistas a suspeitos
    inserirNaHash("Pegadas de botas sujas", "Sr. Black");
    inserirNaHash("Manchas de farinha", "Sra. White");
    inserirNaHash("Livro fora do lugar", "Detetive Azul");
    inserirNaHash("Pegadas no gramado", "Sra. White");
    inserirNaHash("Vidro quebrado na janela", "Sr. Black");
    inserirNaHash("Carta suspeita sobre a mesa", "Prof. Green");
    inserirNaHash("Frasco de veneno", "Prof. Green");
    inserirNaHash("Rastros de maquiagem", "Sra. White");

    // Árvore de pistas coletadas inicialmente vazia
    PistaNode* arvorePistas = NULL;

    printf("Bem-vindo ao Detective Quest!\nExplore a mansão e colete pistas.\n");

    // Exploração
    explorarSalasComPistas(hall, &arvorePistas);

    // Mostrar todas as pistas coletadas
    printf("\nTodas as pistas coletadas:\n");
    exibirPistas(arvorePistas);

    // Fase de acusação final
    char suspeitoAcusado[50];
    printf("\nDigite o nome do suspeito que deseja acusar: ");
    scanf(" %[^\n]", suspeitoAcusado);

    // Contar quantas pistas apontam para esse suspeito
    int contador = 0;
    void contarPistas(PistaNode* raiz) {
        if (!raiz) return;
        contarPistas(raiz->esquerda);
        if (strcmp(encontrarSuspeito(raiz->pista), suspeitoAcusado) == 0)
            contador++;
        contarPistas(raiz->direita);
    }
    contarPistas(arvorePistas);

    if (contador >= 2)
        printf("\nParabéns! Há evidências suficientes. %s é o culpado!\n", suspeitoAcusado);
    else
        printf("\nAs evidências não são suficientes. %s não pode ser condenado.\n", suspeitoAcusado);

    return 0;
}
