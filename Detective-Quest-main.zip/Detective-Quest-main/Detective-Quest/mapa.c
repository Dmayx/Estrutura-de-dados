#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mapa.h"
#include "pistas.h"
#include "hash.h"

// Cria uma sala dinamicamente
Sala* criarSala(const char* nome, const char* pista) {
    Sala* novaSala = (Sala*) malloc(sizeof(Sala));
    strcpy(novaSala->nome, nome);
    strcpy(novaSala->pista, pista);
    novaSala->esquerda = NULL;
    novaSala->direita = NULL;
    return novaSala;
}

// Cria o mapa completo da mansão
Sala* criarMapa() {
    // Criar todas as salas com pistas
    Sala *hall = criarSala("Hall de Entrada", "Carta misteriosa");
    Sala *salaEstar = criarSala("Sala de Estar", "Pegada suja");
    Sala *cozinha = criarSala("Cozinha", "Faca com impressões");
    Sala *jardim = criarSala("Jardim", "Botas deixadas");
    Sala *biblioteca = criarSala("Biblioteca", "Livro caído");
    Sala *quarto = criarSala("Quarto", "Bilhete rasgado");

    // Montar árvore
    hall->esquerda = salaEstar;
    hall->direita = cozinha;
    salaEstar->esquerda = jardim;
    salaEstar->direita = biblioteca;
    cozinha->direita = quarto;

    return hall;
}

// Explorar salas interativamente e coletar pistas
void explorarSalasComPistas(Sala *atual, PistaNode **raizPistas, HashTabela *tabela) {
    char opcao;
    while (atual != NULL) {
        printf("\nVocê está na sala: %s\n", atual->nome);
        if (strlen(atual->pista) > 0) {
            printf("Você encontrou uma pista: %s\n", atual->pista);
            // Inserir na árvore de pistas e hash
            *raizPistas = inserirPista(*raizPistas, atual->pista);
            inserirNaHash(tabela, atual->pista, "SuspeitoX"); // exemplo de suspeito
        }

        // Se não houver saídas, termina exploração
        if (atual->esquerda == NULL && atual->direita == NULL) {
            printf("Fim do caminho nesta sala.\n");
            break;
        }

        printf("Escolha seu próximo caminho: esquerda(e), direita(d), sair(s): ");
        scanf(" %c", &opcao);

        if (opcao == 'e') {
            atual = atual->esquerda;
        } else if (opcao == 'd') {
            atual = atual->direita;
        } else if (opcao == 's') {
            break;
        } else {
            printf("Opção inválida! Tente novamente.\n");
        }
    }
}

// Liberar memória do mapa
void liberarMapa(Sala *atual) {
    if (atual == NULL) return;
    liberarMapa(atual->esquerda);
    liberarMapa(atual->direita);
    free(atual);
}
