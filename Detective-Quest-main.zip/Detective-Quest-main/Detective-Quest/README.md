# Detective Quest

## Descrição
Detective Quest é um jogo em C no qual o jogador explora uma mansão, coleta pistas e identifica o culpado. O mapa da mansão é representado como uma árvore binária, as pistas coletadas são armazenadas em uma BST e associadas a suspeitos via tabela hash.

## Estrutura do projeto
    - `main.c` - função principal, inicia o jogo.
    - `mapa.c` / `mapa.h` - definição do mapa da mansão.
    - `pistas.c` / `pistas.h` - BST para armazenamento de pistas.
    - `hash.c` / `hash.h` - tabela hash para associar pistas a suspeitos.

## Como compilar
```bash
    gcc main.c mapa.c pistas.c hash.c -o detective

## Como Executar
./detective

Objetivos:

    Explorar a mansão.
    Coletar pistas em cada sala.
    Associar pistas a suspeitos.
    Acusar o culpado e verificar evidências.

### **10. Comandos no MSYS2**
```bash
cd "/c/Users/matheus.eustaquio/Documents/Desafios - Estrutura de Dados em C/detective-quest"

# Compilar
gcc main.c mapa.c pistas.c hash.c -o detective.exe

# Executar
./detective.exe

# Git
git add .
git commit -m "Detective Quest"
git push -u origin main
