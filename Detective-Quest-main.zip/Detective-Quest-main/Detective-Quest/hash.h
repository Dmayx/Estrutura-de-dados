#ifndef HASH_H
#define HASH_H

#define TAM 100

typedef struct HashNode {
    char pista[100];
    char suspeito[50];
    struct HashNode *proximo;
} HashNode;

typedef struct HashTabela {
    HashNode *tabela[TAM];
} HashTabela;

void inicializarHash(HashTabela *ht);
void inserirNaHash(HashTabela *ht, const char *pista, const char *suspeito);
char* encontrarSuspeito(HashTabela *ht, const char *pista);
void verificarSuspeitoFinal(HashTabela *ht, const char *suspeito);
void liberarHash(HashTabela *ht);

#endif
