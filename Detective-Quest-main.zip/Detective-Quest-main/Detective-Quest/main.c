#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mapa.h"
#include "pistas.h"
#include "hash.h"

// Função principal: monta o mapa e inicia a exploração
int main() {
    // Criar mapa da mansão
    Sala *hall = criarMapa();

    // Inicializar árvore de pistas coletadas
    PistaNode *raizPistas = NULL;

    // Inicializar tabela hash de pistas -> suspeitos
    HashTabela tabela;
    inicializarHash(&tabela);

    printf("Bem-vindo ao Detective Quest!\n");
    printf("Explore a mansão, colete pistas e descubra o culpado.\n\n");

    // Explorar a mansão interativamente
    explorarSalasComPistas(hall, &raizPistas, &tabela);

    // Exibir todas as pistas coletadas em ordem alfabética
    printf("\nPistas coletadas em ordem alfabética:\n");
    exibirPistas(raizPistas);

    // Solicitar acusação do suspeito
    char suspeito[50];
    printf("\nQuem é o suspeito? ");
    scanf(" %[^\n]", suspeito);

    // Verificar se há pistas suficientes para a acusação
    verificarSuspeitoFinal(&tabela, suspeito);

    printf("\nFim do jogo. Obrigado por jogar Detective Quest!\n");

    // Liberar memória alocada
    liberarMapa(hall);
    liberarPistas(raizPistas);
    liberarHash(&tabela);

    return 0;
}
