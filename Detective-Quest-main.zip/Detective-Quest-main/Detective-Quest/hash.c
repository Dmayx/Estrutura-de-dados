#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

// Função hash simples
unsigned int hash(const char *str) {
    unsigned int h = 0;
    for (; *str; str++) h += *str;
    return h % TAM;
}

void inicializarHash(HashTabela *ht) {
    for (int i = 0; i < TAM; i++)
        ht->tabela[i] = NULL;
}

void inserirNaHash(HashTabela *ht, const char *pista, const char *suspeito) {
    unsigned int h = hash(pista);
    HashNode *novo = (HashNode*) malloc(sizeof(HashNode));
    strcpy(novo->pista, pista);
    strcpy(novo->suspeito, suspeito);
    novo->proximo = ht->tabela[h];
    ht->tabela[h] = novo;
}

char* encontrarSuspeito(HashTabela *ht, const char *pista) {
    unsigned int h = hash(pista);
    HashNode *atual = ht->tabela[h];
    while (atual != NULL) {
        if (strcmp(atual->pista, pista) == 0)
            return atual->suspeito;
        atual = atual->proximo;
    }
    return NULL;
}

void verificarSuspeitoFinal(HashTabela *ht, const char *suspeito) {
    int cont = 0;
    for (int i = 0; i < TAM; i++) {
        HashNode *atual = ht->tabela[i];
        while (atual != NULL) {
            if (strcmp(atual->suspeito, suspeito) == 0)
                cont++;
            atual = atual->proximo;
        }
    }
    if (cont >= 2)
        printf("\nAcusação correta! Suspeito %s possui evidências suficientes (%d pistas).\n", suspeito, cont);
    else
        printf("\nAcusação incorreta. Suspeito %s possui apenas %d pistas.\n", suspeito, cont);
}

// Liberar memória da tabela hash
void liberarHash(HashTabela *ht) {
    for (int i = 0; i < TAM; i++) {
        HashNode *atual = ht->tabela[i];
        while (atual != NULL) {
            HashNode *tmp = atual;
            atual = atual->proximo;
            free(tmp);
        }
        ht->tabela[i] = NULL;
    }
}
