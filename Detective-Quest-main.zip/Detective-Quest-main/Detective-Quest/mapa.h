#ifndef MAPA_H
#define MAPA_H

typedef struct Sala {
    char nome[50];
    char pista[100];
    struct Sala *esquerda;
    struct Sala *direita;
} Sala;

Sala* criarSala(const char* nome, const char* pista);
Sala* criarMapa();
void explorarSalasComPistas(Sala *atual, struct PistaNode **raizPistas, struct HashTabela *tabela);
void liberarMapa(Sala *atual);

#endif
